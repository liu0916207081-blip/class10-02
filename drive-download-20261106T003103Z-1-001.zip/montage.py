from PIL import Image
import glob
files=sorted(glob.glob('prd_render/page-*.png'))
thumbs=[]
for f in files:
 im=Image.open(f).convert('RGB'); im.thumbnail((510,660)); thumbs.append(im.copy())
out=Image.new('RGB',(1020,1320),'#ddd')
for i,im in enumerate(thumbs): out.paste(im,((i%2)*510,(i//2)*660))
out.save('prd_render/contact.png')
