from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from pathlib import Path

out=Path('個人行程與任務管理系統_PRD.docx')
doc=Document()
sec=doc.sections[0]
sec.top_margin=Inches(.68); sec.bottom_margin=Inches(.65); sec.left_margin=Inches(.78); sec.right_margin=Inches(.78)
styles=doc.styles
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3']:
    st=styles[name]; st.font.name='Microsoft JhengHei'; st._element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft JhengHei')
styles['Normal'].font.size=Pt(9.5);styles['Normal'].font.color.rgb=RGBColor(50,55,70);styles['Normal'].paragraph_format.space_after=Pt(5)
styles['Title'].font.size=Pt(27);styles['Title'].font.bold=True;styles['Title'].font.color.rgb=RGBColor(28,34,56);styles['Title'].paragraph_format.space_after=Pt(5)
styles['Subtitle'].font.size=Pt(11);styles['Subtitle'].font.color.rgb=RGBColor(105,111,132)
for nm,size in [('Heading 1',16),('Heading 2',12),('Heading 3',10)]:
    st=styles[nm];st.font.size=Pt(size);st.font.bold=True;st.font.color.rgb=RGBColor(45,53,91);st.paragraph_format.space_before=Pt(12);st.paragraph_format.space_after=Pt(5);st.paragraph_format.keep_with_next=True

def shade(cell,fill):
    pr=cell._tc.get_or_add_tcPr(); sh=OxmlElement('w:shd');sh.set(qn('w:fill'),fill);pr.append(sh)
def set_cell(cell,text,bold=False,color=None,size=8.5):
    cell.text='';p=cell.paragraphs[0];p.paragraph_format.space_after=Pt(1)
    r=p.add_run(str(text));r.bold=bold;r.font.name='Microsoft JhengHei';r._element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft JhengHei');r.font.size=Pt(size)
    if color:r.font.color.rgb=RGBColor(*color)
    cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER

def table(headers, rows, widths=None):
    t=doc.add_table(rows=1, cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.style='Table Grid';t.autofit=False
    for i,h in enumerate(headers):set_cell(t.rows[0].cells[i],h,True,(255,255,255),8.5);shade(t.rows[0].cells[i],'46517F')
    for j,row in enumerate(rows):
        cells=t.add_row().cells
        for i,val in enumerate(row):set_cell(cells[i],val,size=8.2);shade(cells[i],'F3F5FA' if j%2==0 else 'FFFFFF')
    if widths:
        for row in t.rows:
            for i,w in enumerate(widths):row.cells[i].width=Inches(w)
    doc.add_paragraph().paragraph_format.space_after=Pt(1)
    return t

def bullet(text,level=0):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2');p.paragraph_format.space_after=Pt(2);p.add_run(text);return p

p=doc.add_paragraph();p.style='Title';p.add_run('個人行程與任務管理系統')
p=doc.add_paragraph();p.style='Subtitle';p.add_run('產品需求文件 PRD｜第一版原型規格')
p=doc.add_paragraph();p.paragraph_format.space_before=Pt(8);p.paragraph_format.space_after=Pt(10)
r=p.add_run('文件版本 1.0   |   日期 2026 年 10 月 30 日   |   狀態 初版需求基線');r.font.size=Pt(9);r.font.color.rgb=RGBColor(105,111,132)

p=doc.add_paragraph();p.paragraph_format.space_after=Pt(10);p.add_run('本文件整理目前已確認的產品方向與原型需求，供後續設計、開發與驗收使用。產品以桌面週曆為主要入口，協助個人管理生活行程、學習計畫與待辦；原型資料先儲存在使用者瀏覽器本機。')

doc.add_heading('1 產品概述',level=1)
doc.add_paragraph('日序是一套以週曆為核心的個人行程與任務管理系統。使用者可在同一個介面安排日常生活、學習、休閒與待辦事項，透過今日任務掌握當日節奏，並以科目資料夾整理學習計畫。')
table(['項目','說明'],[
('產品目標','降低個人生活、學習與待辦事項分散管理的成本，讓使用者快速掌握每週與每日安排。'),
('主要使用者','需要自行安排個人生活、學習計畫及日常待辦的個人使用者。'),
('主要裝置','桌面電腦優先；版面需支援窄螢幕瀏覽。'),
('產品形態','目前為 HTML、CSS、JavaScript 單頁前端原型；無伺服器與登入。'),
('儲存方式','瀏覽器 localStorage；清除瀏覽器資料可能導致原型資料遺失。')],[1.35,5.7])

doc.add_heading('2 使用者需求與成功目標',level=1)
for x in ['我想用週曆掌握一週各日的行程與每小時安排。','我想將學習、日常休閒、生活事項及待辦清楚區分。','我想查看今日行程與任務，依時間順序安排當天計畫。','我想將學習項目按科目分類，並在各科目的資料夾中管理。','我想為重複行程設定提醒，並選擇國定假日或補假是否跳過。'] : bullet(x)
doc.add_paragraph('成功指標（原型可用性目標）：使用者能在不需說明的情況下完成新增行程、查看今日清單、建立科目資料夾及將學習項目歸入科目。正式量化門檻與埋點方式待產品驗證後訂定。')

doc.add_heading('3 資訊架構與主要流程',level=1)
table(['工作區入口','主要內容','核心操作'],[
('週曆','一週七日；整天列與每小時時間軸。','切換前後週、返回本週、搜尋、新增與刪除行程。'),
('今日任務','今天所有行程／待辦依時間排序的清單。','查看時段及分類、勾選完成、新增今日項目。'),
('學習計畫','科目資料夾列表與科目內容。','新增資料夾、進入科目、查看或新增學習項目。'),
('生活記錄','目前為後續擴充入口，尚無功能規格。','待需求訪談確認。'),
('設定','目前為後續擴充入口，尚無功能規格。','待需求訪談確認。')],[1.2,2.7,3.15])

doc.add_heading('4 功能需求',level=1)
doc.add_heading('4.1 週曆與行程管理',level=2)
for x in ['以週檢視為主要畫面，顯示週一至週日；提供整天列及每小時時段。','行程欄位包含名稱、分類、日期、開始時間、結束時間、提醒時間、重複頻率、備註。','支援分類：學習、日常休閒、生活、待辦，並以不同顏色辨識。','可新增項目；點選週曆空白時段時，日期預先帶入新增表單。','可搜尋行程名稱與備註；可刪除行程。','重複頻率目前規劃為不重複、每天、每週、每月。原型中重複欄位先記錄規則，跨日展開的完整 recurrence engine 尚待實作確認。'] : bullet(x)
doc.add_heading('4.2 今日任務',level=2)
for x in ['透過左側「今日任務」按鈕進入主畫面今日清單。','彙整今天排定的行程與任務，依開始時間由早至晚排序；整天項目排在有時間項目之前。','每筆顯示開始與結束時間；無指定時間則顯示「整天」。','顯示項目名稱、分類、提醒與重複狀態；可勾選完成，完成狀態以項目 ID 本機儲存。','標示當日國定假日／補假；若項目啟用假日跳過且當日為假日，則不列入今日清單。'] : bullet(x)
doc.add_heading('4.3 學習計畫與科目資料夾',level=2)
for x in ['透過左側「學習計畫」按鈕進入科目資料夾總覽。','使用者可建立科目資料夾；目前以科目名稱與識別色呈現。','進入資料夾後，列出已歸入該科目的學習項目，按日期及時間排序。','在資料夾內新增學習項目時，項目類別預設為學習，科目預先指定為目前資料夾。','學習項目仍與週曆共用同一筆資料，更新後在週曆及今日任務共用顯示。'] : bullet(x)
doc.add_heading('4.4 國定假日／補假與提醒',level=2)
for x in ['目前原型內建 2026 年台灣國定假日與補假日期，週曆顯示假日名稱。','重複項目可勾選「國定假日／補假自動跳過」；只隱藏該日的重複發生項目，不刪除原始項目、不移動到其他日期。','假日跳過項目不納入週曆顯示、學習時數和下一個提醒摘要。','提醒時間目前是資料欄位與介面呈現，不代表瀏覽器／作業系統實際送出推播通知。','正式上線前須確認年度假日資料的官方來源、更新流程與補假政策。'] : bullet(x)

doc.add_heading('5 主要資料欄位',level=1)
table(['實體','欄位','說明'],[
('行程／任務','id、title、category、date、time、end','識別碼、名稱、分類、日期、開始及結束時間。'),
('行程／任務','reminder、repeat、skipHolidays、note','提醒時間、重複規則、假日跳過設定、備註。'),
('學習項目','subjectId','關聯科目資料夾；非學習項目可為空。'),
('科目資料夾','id、name、color','資料夾識別碼、科目名稱、識別色。'),
('完成狀態','itemId → boolean','今日任務完成狀態，以項目 ID 對應儲存。')],[1.15,2.45,3.45])

doc.add_heading('6 非功能需求與限制',level=1)
for x in ['易讀、低干擾的桌面介面；手機寬度下可瀏覽主要內容。','原型不需安裝依賴，瀏覽器可直接開啟 HTML 檔。','使用者資料目前只存在本機瀏覽器，不支援跨裝置同步、帳號登入或雲端備份。','原型假日資料只涵蓋 2026 年；其他年度不保證顯示完整。','提醒不具作業系統通知能力；需額外設計通知權限、背景執行及提醒排程。','重複規則欄位已保留，但目前資料渲染主要以單筆日期為準；週期展開、例外日期與修改整個系列需另行設計。'] : bullet(x)

doc.add_heading('7 驗收條件',level=1)
table(['編號','驗收條件'],[
('AC-01','按左側「今日任務」後，主區顯示今天項目，並依開始時間排序。'),
('AC-02','今日任務每列顯示時間範圍、名稱與分類；可勾選完成且重整後保留。'),
('AC-03','按左側「學習計畫」後，主區顯示科目資料夾總覽；可建立並開啟科目。'),
('AC-04','從科目資料夾新增學習項目後，該項目關聯正確科目，並能在該資料夾及週曆看到。'),
('AC-05','在 2026 年假日週檢視時顯示假日名稱；已啟用假日跳過的重複項目不顯示於假日當日。'),
('AC-06','學習、日常休閒、生活與待辦在週曆以不同標籤／色彩呈現。'),
('AC-07','由週曆與兩個工作區頁面可互相返回；新增資料持續保存在本機。')],[.75,6.3])

doc.add_heading('8 版本規劃建議',level=1)
table(['階段','範圍'],[
('目前原型','桌面週曆、分類、假日標示及跳過、今日任務、科目資料夾、瀏覽器本機儲存。'),
('下一步優先','驗證重複行程的實際展開規則；完整處理提醒的觸發方式；補足年度假日資料來源。'),
('後續評估','編輯項目、重複系列例外、拖曳排程、跨裝置同步、匯入／匯出與通知。')],[1.25,5.8])

doc.add_heading('9 待確認事項',level=1)
for x in ['假日跳過應適用於所有重複類型，還是只對學習與工作型安排預設啟用？休閒活動是否也自動跳過？','假日上的重複行程應單純略過，或順延至下一個非假日？目前原型採略過、不順延。','每日任務清單的時間未設定項目是否應固定置頂？目前規格採「整天」置前。','學習科目資料夾是否需要子資料夾、章節、學習目標、進度或附件？','提醒應以頁面內提醒、瀏覽器通知、電子郵件或行動裝置推播為目標？','正式部署是否需要帳號登入、跨裝置同步及雲端備份？'] : bullet(x)

# Footer with page number
for section in doc.sections:
    footer=section.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    run=footer.add_run('日序 PRD  |  ');run.font.name='Microsoft JhengHei';run._element.rPr.rFonts.set(qn('w:eastAsia'),'Microsoft JhengHei');run.font.size=Pt(8);run.font.color.rgb=RGBColor(120,125,140)
    fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');footer._p.append(fld)

doc.save(out)
print(out.resolve())
